<?php
include_once './lib/Constantes.class.php';
header("Location: " . Constantes::HOMEURL);
?>
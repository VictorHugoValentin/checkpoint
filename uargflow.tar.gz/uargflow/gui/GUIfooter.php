<footer id="main-footer">
    <p>
        &copy; Servicio de Inform&aacute;tica y Telecomunicaciones (SIT) - UARG <br /> 
        <b>Enlaces</b> .:
        <a href="http://www.uarg.unpa.edu.ar" target="_blank" title="Ir a Portal UARG">Portal UARG</a> :: 
        <a href="../Instructivo.pdf" target="_blank" title="Ver Manual de Uso">Manual de Uso</a> :.
    </p>
</footer><!-- / #main-footer -->
